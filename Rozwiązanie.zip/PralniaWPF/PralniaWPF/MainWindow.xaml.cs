﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PralniaWPF
{
    public partial class MainWindow : Window
    {
        decimal CenaUslugi = 0;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void ZamowUsluge_Click(object sender, RoutedEventArgs e)
        {
            string stalyKlient = "";
            string usluga = "";
            ZmienCene();
            if(Pranie.IsChecked == true)
            {
                usluga = "Pranie";
            }
            if(Suszenie.IsChecked == true)
            {
                usluga = "Suszenie";
            }
            if(PranieISuszenie.IsChecked == true) 
            {
                usluga = "Pranie i suszenie";
            }
            if(StalyKlient.IsChecked == true)
            {
                stalyKlient = "Tak";
            }
            else
            {
                stalyKlient = "Nie";
            }
            MessageBox.Show($"Usługa: {usluga}, Cena {CenaUslugi}zł, Stały klient: {stalyKlient}");
        }
        private void SprawdzCene_Click(object sender, RoutedEventArgs e)
        {
            ZmienCene();
            Cena.Content = $"Cena: {CenaUslugi}zł";
        }
        public void ZmienCene()
        {
            if (Pranie.IsChecked == true)
            {
                CenaUslugi = 20;
            }
            if (Suszenie.IsChecked == true)
            {
                CenaUslugi = 15;
            }
            if (PranieISuszenie.IsChecked == true)
            {
                CenaUslugi = 30;
            }
            if(StalyKlient.IsChecked == true)
            {
                double kwotaRabatu = double.Parse(CenaUslugi.ToString()) * 0.1;
                decimal cena = Math.Round(CenaUslugi - decimal.Parse(kwotaRabatu.ToString()), 2);
                CenaUslugi = cena;
            }
        }

        private void Pranie_Click(object sender, RoutedEventArgs e)
        {
            PralkaISuszarka.Source = new BitmapImage(new Uri("pralka.jpg", UriKind.RelativeOrAbsolute));
            PralkaISuszarka.Visibility = Visibility.Visible;
            Pralka.Visibility = Visibility.Hidden;
            Suszarka.Visibility = Visibility.Hidden;
        }

        private void Suszenie_Click(object sender, RoutedEventArgs e)
        {
            PralkaISuszarka.Source = new BitmapImage(new Uri("suszarka.jpg", UriKind.RelativeOrAbsolute));
            PralkaISuszarka.Visibility = Visibility.Visible;
            Pralka.Visibility = Visibility.Hidden;
            Suszarka.Visibility = Visibility.Hidden;
        }

        private void PranieISuszenie_Click(object sender, RoutedEventArgs e)
        {
            PralkaISuszarka.Visibility = Visibility.Hidden;
            Pralka.Visibility = Visibility.Visible;
            Suszarka.Visibility = Visibility.Visible;
        }
    }
}